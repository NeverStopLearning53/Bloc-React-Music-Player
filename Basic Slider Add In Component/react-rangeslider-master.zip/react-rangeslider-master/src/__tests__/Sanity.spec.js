describe('Sanity Specs', () => {
  it('should evaluate true to be truthy', () => {
    expect(true).toBeTruthy()
  })
})
