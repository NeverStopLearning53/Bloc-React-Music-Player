import Rangeslider from './Rangeslider'
export default Rangeslider
